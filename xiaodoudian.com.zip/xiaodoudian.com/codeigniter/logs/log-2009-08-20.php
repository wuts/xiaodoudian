<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-20 14:09:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-20 14:09:57 --> 404 Page Not Found --> 
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:09:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-20 14:10:01 --> 404 Page Not Found --> 
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-20 14:10:03 --> 404 Page Not Found --> 
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-20 14:10:04 --> 404 Page Not Found --> 
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-20 14:10:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
