<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:43:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:44:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 11:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 12:04:11 --> 404 Page Not Found --> 
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 12:04:12 --> 404 Page Not Found --> 
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 12:04:13 --> 404 Page Not Found --> 
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 12:04:16 --> 404 Page Not Found --> 
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> 404 Page Not Found --> groups/images
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:04:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 12:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:22:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:26:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:29:16 --> Severity: Notice  --> Undefined variable: theme_view_folder D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 6
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-10-07 16:29:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:31:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 16
ERROR - 2009-10-07 16:32:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 17
ERROR - 2009-10-07 16:32:24 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:32:28 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:38:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:39:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 16:39:39 --> 404 Page Not Found --> 
ERROR - 2009-10-07 16:40:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-07 16:40:01 --> 404 Page Not Found --> 
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:40:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:29 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:41:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:33 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:41:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:41:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:42:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:42 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:43:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:43:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 11
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:47:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-07 16:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-07 16:48:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\libraries\Admin_Controller.php 64
