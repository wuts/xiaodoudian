<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 06:29:56 --> 404 Page Not Found --> 
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 06:30:04 --> 404 Page Not Found --> 
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 06:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:08:59 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:08:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:10:15 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:10:23 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:10:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:11:23 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:11:33 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:11:36 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:11:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:11:41 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:11:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:11:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:11:51 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:11:53 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:11:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:12:07 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:12:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:13:39 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:13:39 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-16 07:13:41 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-16 07:13:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:13:41 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:13:41 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-16 07:13:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:13:46 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:13:48 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:50 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:57 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:14:03 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:14:05 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:14:08 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:14:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:17:59 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 07:29:05 --> 404 Page Not Found --> 
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 07:29:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 08:42:01 --> 404 Page Not Found --> 
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 08:42:41 --> 404 Page Not Found --> 
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 08:42:56 --> 404 Page Not Found --> 
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:42:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 08:43:00 --> 404 Page Not Found --> 
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 08:43:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 09:09:12 --> 404 Page Not Found --> 
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 09:09:27 --> 404 Page Not Found --> 
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 09:09:29 --> 404 Page Not Found --> 
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 09:09:30 --> 404 Page Not Found --> 
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 09:09:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:49 --> 404 Page Not Found --> 
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:22:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 11:24:39 --> 404 Page Not Found --> 
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 11:24:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 11:24:43 --> 404 Page Not Found --> 
ERROR - 2009-08-16 11:37:23 --> 404 Page Not Found --> 
ERROR - 2009-08-16 11:42:04 --> Severity: Warning  --> fopen(application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 280
ERROR - 2009-08-16 11:42:04 --> Unable to write Cache file: application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache
ERROR - 2009-08-16 12:17:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:17:39 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:18:01 --> Severity: Warning  --> fopen(application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 280
ERROR - 2009-08-16 12:18:01 --> Unable to write Cache file: application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache
ERROR - 2009-08-16 12:18:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:18:01 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:18:22 --> Severity: Warning  --> fopen(application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 280
ERROR - 2009-08-16 12:18:22 --> Unable to write Cache file: application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache
ERROR - 2009-08-16 12:18:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:18:23 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:18:44 --> Severity: Warning  --> fopen(application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 280
ERROR - 2009-08-16 12:18:44 --> Unable to write Cache file: application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:19:44 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:19:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:20:49 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:20:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-16 12:21:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 12:21:01 --> 404 Page Not Found --> 
ERROR - 2009-08-16 12:21:22 --> Severity: Warning  --> fopen(application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 280
ERROR - 2009-08-16 12:21:22 --> Unable to write Cache file: application/cache/twitter_lib\aa98bec878782be32448b752d3c8ca808f81e049.cache
ERROR - 2009-08-16 12:54:43 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 12:54:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-16 13:23:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:23:35 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:23:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:23:35 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:23:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:23:35 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:23:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:23:35 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:23:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:23:35 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:33:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:34:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:37:15 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:37:16 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-08-16 13:37:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-08-16 13:39:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:41:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-08-16 13:42:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-08-16 13:43:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:43:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:44:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:46:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:46:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:48:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:51:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:53:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:54:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-16 13:57:12 --> 404 Page Not Found --> 
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 13:57:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:05:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:06:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:26:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 37
ERROR - 2009-08-16 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
