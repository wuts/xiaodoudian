<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-10-18 14:45:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:30 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:30 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:32 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:34 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:35 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-18 14:45:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-18 14:45:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-18 14:45:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:36 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:45:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:45:43 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:46:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-18 14:46:21 --> 404 Page Not Found --> 
ERROR - 2009-10-18 14:46:30 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:33 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:36 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:37 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:39 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:40 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:42 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:43 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:44 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-18 14:46:46 --> 404 Page Not Found --> admin/images
