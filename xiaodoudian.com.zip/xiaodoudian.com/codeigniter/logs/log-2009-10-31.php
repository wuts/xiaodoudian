<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-10-31 01:48:35 --> 404 Page Not Found --> 
ERROR - 2009-10-31 01:48:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-31 01:48:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-31 01:48:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-10-31 01:48:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 01:48:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 01:48:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 01:48:38 --> 404 Page Not Found --> 
ERROR - 2009-10-31 01:48:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 01:48:40 --> 404 Page Not Found --> 
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:26 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-31 01:50:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-31 01:50:29 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-31 01:50:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:47 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 01:50:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 03:13:54 --> Severity: Warning  --> Missing argument 2 for CI_Loader::module_model(), called in D:\xampp\htdocs\xiaodoudian.com\application\modules\home\controllers\home.php on line 7 and defined D:\xampp\htdocs\xiaodoudian.com\application\libraries\Loader.php 76
ERROR - 2009-10-31 03:13:54 --> Severity: Notice  --> Undefined variable: model D:\xampp\htdocs\xiaodoudian.com\application\libraries\Loader.php 78
ERROR - 2009-10-31 03:13:54 --> Severity: Warning  --> Missing argument 2 for CI_Loader::module_model(), called in D:\xampp\htdocs\xiaodoudian.com\application\modules\home\controllers\home.php on line 8 and defined D:\xampp\htdocs\xiaodoudian.com\application\libraries\Loader.php 76
ERROR - 2009-10-31 03:13:54 --> Severity: Notice  --> Undefined variable: model D:\xampp\htdocs\xiaodoudian.com\application\libraries\Loader.php 78
ERROR - 2009-10-31 03:19:39 --> Language file contains no data: language/english/home_lang.php
ERROR - 2009-10-31 03:19:39 --> Severity: Notice  --> Undefined variable: photos D:\xampp\htdocs\xiaodoudian.com\application\modules\home\controllers\home.php 15
ERROR - 2009-10-31 03:21:44 --> Language file contains no data: language/english/home_lang.php
ERROR - 2009-10-31 05:27:58 --> Severity: Notice  --> Undefined variable: galleries D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\index.php 24
ERROR - 2009-10-31 05:28:02 --> Severity: Notice  --> Undefined variable: galleries D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\index.php 24
ERROR - 2009-10-31 05:28:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\index.php 8
ERROR - 2009-10-31 05:28:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 3
ERROR - 2009-10-31 05:28:45 --> Severity: Notice  --> Undefined variable: photos D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 9
ERROR - 2009-10-31 05:29:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 3
ERROR - 2009-10-31 05:37:20 --> Severity: Notice  --> Use of undefined constant title - assumed 'title' D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: Notice  --> Use of undefined constant title - assumed 'title' D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: Notice  --> Use of undefined constant title - assumed 'title' D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: Notice  --> Use of undefined constant title - assumed 'title' D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:20 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 5
ERROR - 2009-10-31 05:37:55 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 05:38:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 05:39:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 06:11:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 06:14:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 06:51:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 07:00:34 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\models\galleries_m.php 88
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:00:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-10-31 07:01:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\home\views\index.php 15
ERROR - 2009-10-31 07:15:29 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:15:52 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:16:12 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 07:16:16 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 07:16:17 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 07:16:18 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 07:16:19 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 07:17:15 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:17:15 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:17:15 --> Severity: Warning  --> unlink(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 229
ERROR - 2009-10-31 07:17:15 --> Severity: Warning  --> copy(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.copy'>function.copy</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 240
ERROR - 2009-10-31 07:17:15 --> Severity: Warning  --> move_uploaded_file(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:17:15 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php46.tmp' to 'D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/' D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:17:15 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2009-10-31 07:17:46 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:17:46 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:17:46 --> Severity: Warning  --> unlink(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 229
ERROR - 2009-10-31 07:17:46 --> Severity: Warning  --> copy(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.copy'>function.copy</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 240
ERROR - 2009-10-31 07:17:46 --> Severity: Warning  --> move_uploaded_file(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:17:46 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php47.tmp' to 'D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/' D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:17:46 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2009-10-31 07:18:25 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:18:25 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:18:25 --> Severity: Warning  --> unlink(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 229
ERROR - 2009-10-31 07:18:25 --> Severity: Warning  --> copy(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.copy'>function.copy</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 240
ERROR - 2009-10-31 07:18:25 --> Severity: Warning  --> move_uploaded_file(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:18:25 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php48.tmp' to 'D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/' D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:18:25 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2009-10-31 07:18:59 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:18:59 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:18:59 --> Severity: Warning  --> unlink(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 229
ERROR - 2009-10-31 07:18:59 --> Severity: Warning  --> copy(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.copy'>function.copy</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 240
ERROR - 2009-10-31 07:18:59 --> Severity: Warning  --> move_uploaded_file(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:18:59 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php49.tmp' to 'D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/' D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:18:59 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2009-10-31 07:34:56 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:34:56 --> Severity: Notice  --> Undefined variable: filename_hash D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 319
ERROR - 2009-10-31 07:34:56 --> Severity: Warning  --> unlink(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 229
ERROR - 2009-10-31 07:34:56 --> Severity: Warning  --> copy(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.copy'>function.copy</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 240
ERROR - 2009-10-31 07:34:56 --> Severity: Warning  --> move_uploaded_file(D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: Permission denied D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:34:56 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php4A.tmp' to 'D:/xampp/htdocs/xiaodoudian.com/application/assets/img/staff/' D:\xampp\htdocs\xiaodoudian.com\application\libraries\MY_Upload.php 242
ERROR - 2009-10-31 07:34:56 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2009-10-31 07:43:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:43:34 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:43:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:43:50 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:52:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:52:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:52:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:52:57 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:56:08 --> Severity: Notice  --> Undefined property: stdClass::$id D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\admin\form.php 18
ERROR - 2009-10-31 07:56:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:56:18 --> 404 Page Not Found --> 
ERROR - 2009-10-31 07:59:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 07:59:24 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:01:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:01:26 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:01:31 --> 404 Page Not Found --> admin/images
ERROR - 2009-10-31 08:12:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:12:29 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:12:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:12:29 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:12:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:12:29 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:12:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:12:29 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:30 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:30 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:30 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:30 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:38 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:38 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:13:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:13:38 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:14:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:14:40 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:14:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:14:40 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:14:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:14:40 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:14:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:14:40 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:15:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:15:49 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:15:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:15:49 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:15:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:15:49 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:15:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:15:50 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:16:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:16:02 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:16:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:16:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:16:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:16:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:16:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:16:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:16:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:16:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:21:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:21:32 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:21:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:21:32 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:21:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:21:32 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:21:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:21:32 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:23:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:23:02 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:23:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:23:03 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:23:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:23:03 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:23:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:23:03 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:26:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:26:36 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:26:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:26:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:26:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:26:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:26:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:26:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 08:26:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 08:26:37 --> 404 Page Not Found --> 
ERROR - 2009-10-31 09:20:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 09:20:29 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 09:20:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 11:08:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 11:08:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 11:08:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-10-31 11:54:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:54:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:54:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:54:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:54:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:54:05 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:54:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:54:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:01 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:02 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:02 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:02 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:04 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:42 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:43 --> 404 Page Not Found --> 
ERROR - 2009-10-31 11:59:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 11:59:43 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:47 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:47 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:47 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:58 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:58 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:00:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:00:58 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:01:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:01:45 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:01:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:01:46 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:01:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:01:46 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:01:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:01:58 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:01:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:01:58 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:06 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:02:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:02:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:08 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:08 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:09 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:10 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:57 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:02:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:02:57 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:04:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:04:42 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:04:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:04:42 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:11:47 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:11:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:11:47 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:03 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:03 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:05 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:05 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:07 --> 404 Page Not Found --> 
ERROR - 2009-10-31 12:12:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-10-31 12:12:07 --> 404 Page Not Found --> 
