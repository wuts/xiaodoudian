<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-03 10:58:15 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:04:12 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:04:15 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:05:05 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:05:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:05:17 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:07:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:07:42 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:15:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:15:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:15:46 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:16:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:16:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:16:43 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:17:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:17:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:17:54 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:18:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:18:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:18:30 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:23:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:23:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:23:08 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:23:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:23:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:23:33 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:26:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:26:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:26:01 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:29:32 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:29:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:29:34 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:29:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-03 14:29:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-03 14:29:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:29:35 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:29:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:29:40 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:30:54 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:35:56 --> You did not select a file to upload.
ERROR - 2009-08-03 14:38:03 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:39:51 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:39:59 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:41:05 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-03 14:41:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:41:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:41:09 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:41:21 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:41:22 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:41:23 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:50:41 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 14:50:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:50:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:50:43 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:50:47 --> 404 Page Not Found --> 
ERROR - 2009-08-03 14:50:49 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-03 14:50:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-03 14:50:51 --> 404 Page Not Found --> 
ERROR - 2009-08-03 15:03:51 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:03:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-03 15:03:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-03 15:03:53 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:03:54 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:03:56 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:03:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-03 15:03:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-03 15:03:57 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:45:44 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:45:50 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:45:52 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-03 15:45:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-03 15:45:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
