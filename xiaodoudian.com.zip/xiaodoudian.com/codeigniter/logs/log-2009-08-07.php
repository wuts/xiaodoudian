<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-07 15:53:59 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:00 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:01 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-07 15:54:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-07 15:54:02 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:03 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:04 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:05 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 15:54:06 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-07 17:02:00 --> 404 Page Not Found --> admin/images
