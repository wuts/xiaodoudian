<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:17:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 01:18:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:10:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:06 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-11-07 02:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:11:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:11:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:36 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 02:28:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:28:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 02:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 02:56:27 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 02:56:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 04:05:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 04:06:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:26 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 06:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:38 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 06:17:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:18:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 06:58:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 06:58:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 06:58:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:05 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:14 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:45 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:05:46 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:05:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 07:06:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:06:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:06:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:06:25 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:26 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:06:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:29 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:06:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:29 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:39 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:40 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:53 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:06:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:06:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 07:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 07:07:06 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:06 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:06 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:06 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:15 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:15 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:18 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:20 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:21 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:23 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:07:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:07:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:29 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:07:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:07:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:21 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:21 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:08:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:22 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:31 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:44 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:08:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:08:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\models\pages_m.php 127
ERROR - 2009-11-07 07:09:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\models\pages_m.php 127
ERROR - 2009-11-07 07:09:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\models\pages_m.php 127
ERROR - 2009-11-07 07:09:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:11 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:16 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:23 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:25 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:31 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:09:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:09:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:10:15 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:15 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:10:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:10:18 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:10:19 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:19 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:10:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:10:44 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:44 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:10:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:10:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:10:48 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:11:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:11:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:11:30 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:11:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:11:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:11:36 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:11:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:11:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:11:49 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:11:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:11:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:11:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:11:52 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:12:06 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:06 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:06 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:12:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:12:07 --> 404 Page Not Found --> home/admin
ERROR - 2009-11-07 07:12:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:12:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:21 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:22 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:25 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:14:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:44 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:51 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:53 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:14:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:14:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:15:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:15:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:03 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:15 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:16 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:19 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:20 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:20 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:21 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:23 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:25 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:26 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:30 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:30 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:40 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:41 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:16:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:16:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:16:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:22:57 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:22:57 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:22:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:22:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:22:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:22:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:23:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:23:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:23:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:23:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:23:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:23:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:14: parser error : Opening and ending tag mismatch: fr line 12 and description D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: 	&lt;/description&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: 	              ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:36: parser error : Opening and ending tag mismatch: description line 9 and module D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: &lt;/module&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]:          ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:36: parser error : Premature end of data in tag module line 2 D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: &lt;/module&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]:          ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 114
ERROR - 2009-11-07 07:30:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 114
ERROR - 2009-11-07 07:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 130
ERROR - 2009-11-07 07:30:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 130
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:14: parser error : Opening and ending tag mismatch: fr line 12 and description D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: 	&lt;/description&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: 	              ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:36: parser error : Opening and ending tag mismatch: description line 9 and module D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: &lt;/module&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]:          ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: application/core_modules/themes/details.xml:36: parser error : Premature end of data in tag module line 2 D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]: &lt;/module&gt; D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> simplexml_load_file() [<a href='function.simplexml-load-file'>function.simplexml-load-file</a>]:          ^ D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 109
ERROR - 2009-11-07 07:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 114
ERROR - 2009-11-07 07:30:37 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 114
ERROR - 2009-11-07 07:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 130
ERROR - 2009-11-07 07:30:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 130
ERROR - 2009-11-07 07:31:22 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:34:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:34:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:34:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:34:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:34:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:34:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:34:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:34:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:34:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:34:54 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:44:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:44:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\models\pages_m.php 127
ERROR - 2009-11-07 07:46:11 --> Severity: Notice  --> Undefined property: stdClass::$parent_id D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\views\admin\form.php 2
ERROR - 2009-11-07 07:46:13 --> Severity: Notice  --> Undefined property: stdClass::$parent_id D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\views\admin\form.php 2
ERROR - 2009-11-07 07:46:14 --> Severity: Notice  --> Undefined property: stdClass::$parent_id D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\views\admin\form.php 2
ERROR - 2009-11-07 07:46:16 --> Severity: Notice  --> Undefined property: stdClass::$parent_id D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\views\admin\form.php 2
ERROR - 2009-11-07 07:46:19 --> Severity: Notice  --> Undefined property: stdClass::$parent_id D:\xampp\htdocs\xiaodoudian.com\application\core_modules\pages\views\admin\form.php 2
ERROR - 2009-11-07 07:46:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:40 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:41 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:46:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:46:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:01 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:13 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:31 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:38 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:38 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:40 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:40 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:47:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:50 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:51 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:53 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:53 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:54 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:47:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:47:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:48:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:48:45 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:48:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:48:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:48:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:48:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:48:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:48:49 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:48:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:48:53 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:48:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:48:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:49:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:49:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:50:15 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:50:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:50:16 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:50:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:50:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:50:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:50:18 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:51:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:54:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:54:17 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:54:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:54:20 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:54:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:54:23 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:54:39 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:58:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:58:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:58:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:58:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:58:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:59:01 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:59:03 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:59:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:59:13 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 07:59:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 07:59:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:48 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:48 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:48 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 07:59:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:00:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:10 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:11 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:00:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:00:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:54 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:00:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:00:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:01:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:01:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:03:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:03:52 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:25 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:06:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:06:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:31 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:44 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:46 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:06:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:06:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:07:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:07:51 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:09:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:09:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:09:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:09:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:09:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:09:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:09:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:09:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:10:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:10:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:10:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:10:29 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:10:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:10:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:10:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:10:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:12:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:12:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:27 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:28 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:29 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:12:29 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:12:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:29 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:30 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:31 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:12:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:12:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:17:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:17:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:17:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:17:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:17:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:17:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:08 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:08 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:08 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:11 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:11 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:11 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:34 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:18:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:19:03 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:19:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:19:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:19:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:19:05 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:19:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:19:06 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:19:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:19:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:20:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:20:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:20:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:20:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:20:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:21:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:21:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:21:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:21:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:21:54 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:22:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:22:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:22:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:22:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\libraries\Admin_Controller.php 63
ERROR - 2009-11-07 08:22:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:22:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:22:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:23:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:23:07 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:23:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:23:08 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:23:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:23:09 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:23:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:23:10 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:24:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:24:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:24:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:24:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:24:42 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:24:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 4
ERROR - 2009-11-07 08:24:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 11
ERROR - 2009-11-07 08:24:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:24:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:24:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 21
ERROR - 2009-11-07 08:25:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 4
ERROR - 2009-11-07 08:25:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 11
ERROR - 2009-11-07 08:25:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:25:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:25:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 21
ERROR - 2009-11-07 08:25:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 4
ERROR - 2009-11-07 08:25:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 11
ERROR - 2009-11-07 08:25:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:25:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 16
ERROR - 2009-11-07 08:25:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\services\views\admin\form.php 21
ERROR - 2009-11-07 08:25:37 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:26:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:26:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 08:26:32 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:26:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:26:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:26:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:26:38 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:26:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:26:39 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:27:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:27:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:27:13 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:30:54 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:55 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:56 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:58 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:30:59 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:01 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:01 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:01 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:02 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:03 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:03 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 08:31:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:04 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:05 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:31:05 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:31:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:33 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:34 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:34 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 08:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 08:52:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 08:52:36 --> 404 Page Not Found --> 
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 08:52:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:30:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:32:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:32:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 09:34:22 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:24 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:35 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:40 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:48 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:34:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:34:57 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:35:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:35:00 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:35:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:35:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:35:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 09:35:45 --> 404 Page Not Found --> 
ERROR - 2009-11-07 09:38:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 09:39:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 13:39:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:12 --> Severity: Notice  --> unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 77 of 6923 bytes D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 8686
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-07 13:39:17 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:17 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:17 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 13:39:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:39:22 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:39:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:39:43 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:45 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 13:53:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:53:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-07 13:53:47 --> 404 Page Not Found --> 
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 13:56:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 14:10:25 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 14:11:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 14:11:08 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 14:50:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 14:50:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 14:50:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-07 15:03:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 10
