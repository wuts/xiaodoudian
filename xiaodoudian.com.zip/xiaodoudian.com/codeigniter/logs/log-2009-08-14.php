<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:07:52 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:07:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:10:06 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:10:08 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:10:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:21 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:24 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:26 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:44 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:46 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-14 13:17:48 --> 404 Page Not Found --> 
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-14 13:17:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
