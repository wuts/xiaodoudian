<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-11-11 13:50:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 13:50:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 13:50:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 13:50:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:27 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:29 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:30 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:31 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:35 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:41 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:44 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:45 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:50:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 13:50:47 --> 404 Page Not Found --> 
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-11-11 13:51:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-11-11 13:51:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\categories\views\admin\form.php 4
ERROR - 2009-11-11 13:51:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\categories\views\admin\form.php 9
ERROR - 2009-11-11 14:32:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 14:32:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 14:32:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 15:11:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 15:11:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 15:11:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-11 15:11:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 15:11:35 --> 404 Page Not Found --> 
ERROR - 2009-11-11 15:11:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-11 15:11:41 --> 404 Page Not Found --> 
