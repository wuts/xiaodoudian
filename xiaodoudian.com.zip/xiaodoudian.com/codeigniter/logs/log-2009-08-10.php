<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-10 12:57:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 12:57:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 12:57:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 12:58:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 12:58:17 --> Severity: Notice  --> Undefined property: stdClass::$products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 15
ERROR - 2009-08-10 12:58:17 --> Severity: Notice  --> Undefined variable: products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 3
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Notice  --> Undefined property: stdClass::$products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 15
ERROR - 2009-08-10 12:58:33 --> Severity: Notice  --> Undefined variable: products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 3
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Notice  --> Undefined property: stdClass::$products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 15
ERROR - 2009-08-10 12:58:37 --> Severity: Notice  --> Undefined variable: products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 3
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Notice  --> Undefined property: stdClass::$products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 15
ERROR - 2009-08-10 12:58:42 --> Severity: Notice  --> Undefined variable: products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 3
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Notice  --> Undefined property: stdClass::$products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 15
ERROR - 2009-08-10 12:58:52 --> Severity: Notice  --> Undefined variable: products D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 3
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 12:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-10 13:16:30 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 13:16:32 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 13:16:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:32 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:33 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:35 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:36 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:37 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:38 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:39 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:16:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:41 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:42 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:16:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:16:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:43 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:45 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:46 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:48 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:52 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:55 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:16:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:16:58 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:02 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:04 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:05 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:07 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:08 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:09 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:09 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 13:17:09 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 13:17:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:10 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:10 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:11 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:12 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:12 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:13 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:15 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:17:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-10 13:17:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:15 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:17 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:18 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:17:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:17:20 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:26:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:26:12 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-10 13:26:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-10 13:26:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:37:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:37:01 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:37:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:37:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:37:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:14 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:38:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:38:25 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:39:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:31 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:39:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:43 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:39:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:39:53 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:01 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:11 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:14 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:14 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:18 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:19 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:21 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:40:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:40:22 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:42:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:42:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:23 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:49:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:49:27 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:52:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:52:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:52:29 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:52:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:52:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:52:56 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:53:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:53:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:53:15 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:54:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:54:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:54:30 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:55:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:08 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:55:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:31 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:55:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:52 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:55:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:56 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:55:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:55:58 --> 404 Page Not Found --> 
ERROR - 2009-08-10 13:56:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:56:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 13:56:13 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:05:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:05:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:05:51 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:07:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:07:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:07:28 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:18 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:22 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:22 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:25 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:26 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:30 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:30 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:32 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:09:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:09:32 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:11:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:11:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:11:27 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:14:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:14:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:14:55 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:18 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:41 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:43 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:44 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:49 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 14:39:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:49 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 14:39:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:50 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 14:39:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:51 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 14:39:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:53 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:54 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-10 14:39:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:54 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:56 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:57 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:57 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:39:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:39:58 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:41:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:28 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:41:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:29 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:41:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:41:36 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:08 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:09 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:10 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:12 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:13 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:23 --> 404 Page Not Found --> 
ERROR - 2009-08-10 14:42:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-10 14:42:25 --> 404 Page Not Found --> 
