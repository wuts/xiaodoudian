<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-22 01:15:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-22 01:15:03 --> 404 Page Not Found --> 
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:15:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-22 01:41:50 --> 404 Page Not Found --> 
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:41:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-22 01:44:35 --> 404 Page Not Found --> 
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 01:44:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:31:53 --> 404 Page Not Found --> statistics/index
ERROR - 2009-08-22 02:38:28 --> 404 Page Not Found --> test/test_statistics
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:38:35 --> 404 Page Not Found --> statistics/index
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 02:39:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 02:39:54 --> 404 Page Not Found --> statistics/index
ERROR - 2009-08-22 02:40:02 --> 404 Page Not Found --> statistics/test_statistics
ERROR - 2009-08-22 02:40:05 --> 404 Page Not Found --> statistics/test_statistics
ERROR - 2009-08-22 02:42:52 --> 404 Page Not Found --> statistics/index
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:50:54 --> Severity: Notice  --> Undefined index:  user_id D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 79
ERROR - 2009-08-22 04:50:54 --> Severity: Notice  --> Undefined index:  is_active D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 80
ERROR - 2009-08-22 04:50:54 --> Query error: Column 'approval_count' cannot be null
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:51:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php 122
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined index:  user_id D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 93
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined index:  is_active D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 94
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined index:  user_id D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 93
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined index:  is_active D:\xampp\htdocs\xiaodoudian.com\application\modules\statistics\models\statistics_m.php 94
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:54:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:109) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:55:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined property: stdClass::$id D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php 126
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:58:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 04:59:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 05:57:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:05:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:48 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:06:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:11:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:11:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php:31) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:18:15 --> Severity: Notice  --> Undefined property: News::$statistics D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php 32
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:18:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\controllers\news.php 135
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:19:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:20:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 06:21:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:54:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 38
ERROR - 2009-08-22 09:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\lazydays\views\layouts\default.php 39
