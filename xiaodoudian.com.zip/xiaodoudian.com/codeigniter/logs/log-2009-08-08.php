<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-08 01:19:15 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-08 01:23:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-08 01:23:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-08 01:23:21 --> 404 Page Not Found --> 
ERROR - 2009-08-08 14:39:19 --> 404 Page Not Found --> 
ERROR - 2009-08-08 15:36:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-08 15:36:50 --> 404 Page Not Found --> 
ERROR - 2009-08-08 15:36:52 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Undefined variable: article D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Undefined variable: article D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Undefined variable: article D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Undefined variable: article D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Undefined variable: article D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:36:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\products\views\index.php 11
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 35
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 15:44:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\helpers\url_helper.php 541
ERROR - 2009-08-08 15:49:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:33) D:\xampp\htdocs\xiaodoudian.com\codeigniter\helpers\url_helper.php 541
DEBUG - 2009-08-08 15:52:53 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:53 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:53 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:53 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:53 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:53 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:53 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: users
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: users
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: users
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:53 --> No valid caller
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:53 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: xml
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Not found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: helpers/date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/core_modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: date
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> Language file loaded: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:53 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:53 --> Cache retrieved: news_m/daf0726520de58ca6575738afb5ebf2e68fa56b3
DEBUG - 2009-08-08 15:52:53 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:53 --> Finding: views/rss.php
DEBUG - 2009-08-08 15:52:53 --> Calling module: news
DEBUG - 2009-08-08 15:52:53 --> Looking in: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:53 --> Found
DEBUG - 2009-08-08 15:52:53 --> --------------
DEBUG - 2009-08-08 15:52:53 --> File loaded: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:53 --> Final output sent to browser
DEBUG - 2009-08-08 15:52:53 --> Total execution time: 0.3320
DEBUG - 2009-08-08 15:52:54 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:54 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:54 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:54 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:54 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:54 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:54 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: users
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: users
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: users
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:54 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: models/products_m.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: products
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/products/models/products_m.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: products
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/products/language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Language file loaded: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: array
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: inflector
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: inflector
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: views/index.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/products/views/index.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: products
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/products/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/products/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: text
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> File loaded: application/modules/products/views/index.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:54 --> File loaded: application/views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: news
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Not found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: helpers/date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Calling module: news
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> Helpers loaded: date
DEBUG - 2009-08-08 15:52:54 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:54 --> Finding: views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:54 --> No valid caller
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/modules//views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/core_modules//views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:54 --> Looking in: application/views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:54 --> Found
DEBUG - 2009-08-08 15:52:54 --> --------------
DEBUG - 2009-08-08 15:52:54 --> File loaded: application/views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:54 --> File loaded: application/views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:54 --> Final output sent to browser
DEBUG - 2009-08-08 15:52:54 --> Total execution time: 0.4060
DEBUG - 2009-08-08 15:52:55 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:55 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:55 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:55 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:55 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:55 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:55 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: users
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: users
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: users
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:55 --> No valid caller
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:55 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: xml
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Not found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: helpers/date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/core_modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: date
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> Language file loaded: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:55 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:55 --> Cache retrieved: news_m/daf0726520de58ca6575738afb5ebf2e68fa56b3
DEBUG - 2009-08-08 15:52:55 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:55 --> Finding: views/rss.php
DEBUG - 2009-08-08 15:52:55 --> Calling module: news
DEBUG - 2009-08-08 15:52:55 --> Looking in: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:55 --> Found
DEBUG - 2009-08-08 15:52:55 --> --------------
DEBUG - 2009-08-08 15:52:55 --> File loaded: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:55 --> Final output sent to browser
DEBUG - 2009-08-08 15:52:55 --> Total execution time: 0.3355
DEBUG - 2009-08-08 15:52:56 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:56 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:56 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:56 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/products_m.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: products
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/models/products_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: products
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:56 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:56 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:56 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/products_m.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: products
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/models/products_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: products
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/products_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_array_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: array
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_inflector_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: inflector
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: inflector
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: views/index.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/views/index.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: products
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/products/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/products/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_text_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: text
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> File loaded: application/modules/products/views/index.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Asset.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Asset class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> File loaded: application/views/../themes/freshmedia/views/metadata.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: news
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: news
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: date
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> File loaded: application/views/../themes/freshmedia/views/footer.php
DEBUG - 2009-08-08 15:52:56 --> File loaded: application/views/../themes/freshmedia/views/layouts/default.php
DEBUG - 2009-08-08 15:52:56 --> Final output sent to browser
DEBUG - 2009-08-08 15:52:56 --> Total execution time: 0.3704
DEBUG - 2009-08-08 15:52:56 --> Config Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Hooks Class Initialized
DEBUG - 2009-08-08 15:52:56 --> URI Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Matchbox Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Router Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Output Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Input Class Initialized
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> XSS Filtering completed
DEBUG - 2009-08-08 15:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2009-08-08 15:52:56 --> Language Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Loader Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/asset.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/asset.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/language.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/language.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/language.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Config file loaded: config/language.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_url_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: url
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/form_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: form
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/language_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: language
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/matchbox_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/xhtml_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: xhtml
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/asset_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: asset
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/pagination_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: pagination
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/debug_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: debug
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/errors_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/fragments_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/user_lang.php
DEBUG - 2009-08-08 15:52:56 --> Database Driver Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/session.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/string_helper.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: string
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/encrypt.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Encrypt Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Session routines successfully run
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Cache.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/cache.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/cache.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Layout.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/layout.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/layout.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Template Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/MY_Settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/libraries/Settings.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/config/settings.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/settings/models/settings_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Widgets.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/config/widgets.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/permissions/models/permissions_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/news/models/news_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/models/modules_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Helpers loaded: matchbox
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/pages/models/pages_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> Controller Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/models/users_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/User_lib.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/config/user_lib.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> User_lib Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/MY_Session.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/libraries/Session.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Calling module: users
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules/users/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/email_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Language file loaded: language/chinese/main_lang.php
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules/navigation/models/navigation_m.php
DEBUG - 2009-08-08 15:52:56 --> Found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:56 --> Model Class Initialized
DEBUG - 2009-08-08 15:52:56 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:56 --> Finding: helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> No valid caller
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/core_modules//helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Looking in: application/helpers/MY_security_helper.php
DEBUG - 2009-08-08 15:52:56 --> Not found
DEBUG - 2009-08-08 15:52:56 --> --------------
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: helpers/security_helper.php
DEBUG - 2009-08-08 15:52:57 --> No valid caller
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/core_modules//helpers/security_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/security_helper.php
DEBUG - 2009-08-08 15:52:57 --> Found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:57 --> Cache retrieved: navigation_m/7625bed6aa9dface18352e95a00fb3ba4a469491
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/core_modules/news/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/helpers/MY_xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Not found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/core_modules/news/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/xml_helper.php
DEBUG - 2009-08-08 15:52:57 --> Found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> Helpers loaded: xml
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/core_modules/news/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/helpers/MY_date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Not found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: helpers/date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/core_modules/news/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Looking in: D:\xampp\htdocs\xiaodoudian.com/codeigniter/helpers/date_helper.php
DEBUG - 2009-08-08 15:52:57 --> Found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> Helpers loaded: date
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:57 --> Found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> Language file loaded: language/chinese/news_lang.php
DEBUG - 2009-08-08 15:52:57 --> Helpers loaded: security
DEBUG - 2009-08-08 15:52:57 --> Cache retrieved: news_m/daf0726520de58ca6575738afb5ebf2e68fa56b3
DEBUG - 2009-08-08 15:52:57 --> ---Matchbox---
DEBUG - 2009-08-08 15:52:57 --> Finding: views/rss.php
DEBUG - 2009-08-08 15:52:57 --> Calling module: news
DEBUG - 2009-08-08 15:52:57 --> Looking in: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:57 --> Found
DEBUG - 2009-08-08 15:52:57 --> --------------
DEBUG - 2009-08-08 15:52:57 --> File loaded: application/modules/news/views/rss.php
DEBUG - 2009-08-08 15:52:57 --> Final output sent to browser
DEBUG - 2009-08-08 15:52:57 --> Total execution time: 0.3103
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:01:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:48) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:06:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Notice  --> Undefined offset:  6 D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php 49
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:09:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:10:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:12:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:13:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:14:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:18:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:37 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:20:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:22:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:26:50 --> Query error: Unknown column 'catagories.id' in 'field list'
ERROR - 2009-08-08 16:27:30 --> Query error: Unknown column 'category_id' in 'where clause'
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:27:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:45) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php 38
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-08 16:28:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
