<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 12:17:11 --> 404 Page Not Found --> 
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:58 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:17:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:15 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:24:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 12:27:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:49 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:52 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:54 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:55 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:57 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:29:59 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:29:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:30:00 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:30:08 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:30:31 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:30:43 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:30:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:31:06 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:31:08 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:31:10 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:31:26 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:28 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:31:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:32:21 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:25 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:32:28 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:29 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:32:56 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:32:58 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:32:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:32:59 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:33:11 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:33:13 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:33:14 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:33:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:33:18 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:33:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:06 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:09 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:11 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:13 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:14 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:26 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:29 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:31 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:32 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:33 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:35 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:34:37 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:34:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:35:17 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:35:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:37:57 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:37:59 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:37:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:38:02 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:38:06 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:38:08 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:38:10 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:38:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:39:42 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:39:43 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:39:46 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:39:49 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:39:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:48:20 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:48:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:49:02 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:49:13 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:49:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:50:51 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:50:52 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:50:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:53:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:53:24 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:53:31 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:53:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:54:14 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:18 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:54:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:17 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:55:20 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:22 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:55:34 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:55:37 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:55:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:56:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:56:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:14 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:15 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:20 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:22 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:25 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:28 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:32 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:44 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:56:51 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:51 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-13 14:56:53 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-13 14:56:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:56:53 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:56:54 --> Query error: Table 'xiaodoudian.widgets' doesn't exist
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:02 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:04 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:11 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:40 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: uri D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 147
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:41 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: uri D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 147
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:45 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:46 --> Severity: Notice  --> Undefined variable: uri D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 147
ERROR - 2009-08-13 14:57:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:57:46 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:47 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:57:50 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: uri D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 147
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:57:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:01 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: uri D:\xampp\htdocs\xiaodoudian.com\application\models\modules_m.php 147
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:10 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:12 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:14 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:42 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:47 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:47 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:49 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:58:51 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:58:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:59:19 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:59:20 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:59:22 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 14:59:25 --> 404 Page Not Found --> 
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 14:59:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:00:00 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:00:02 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:00:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:06:45 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:06:47 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:06:53 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:06:56 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:06:58 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:06:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:01 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:03 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:05 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:13 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:13 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:16 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:18 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:07:38 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:07:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:21 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:23 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:25 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:26 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:37 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:38 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:39 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:41 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:42 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:13:57 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:13:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:14:00 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:14:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:16:00 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:16:08 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:16:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:21:31 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:21:42 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:21:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:25:09 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:25:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:47:47 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:47:50 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:47:51 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:47:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:48:04 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:48:54 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:48:56 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:53:33 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:53:35 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-13 15:53:37 --> 404 Page Not Found --> 
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-13 15:53:37 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
