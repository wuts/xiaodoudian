<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-15 02:48:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:48:53 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:48:55 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:48:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 02:48:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 02:48:59 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:22 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:24 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:25 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:26 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:27 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:58:32 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:58:49 --> The upload path does not appear to be valid.
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 02:59:31 --> 404 Page Not Found --> 
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 02:59:47 --> The upload path does not appear to be valid.
ERROR - 2009-08-15 03:03:22 --> The upload path does not appear to be valid.
ERROR - 2009-08-15 03:03:28 --> The upload path does not appear to be valid.
ERROR - 2009-08-15 03:08:22 --> Severity: Warning  --> rename(application/assets/img/galleries/website,application/assets/img/galleries/a015434e0df90bded79afc4957f7768e8cadb8bf12f55793f5af07489e4bb2df) [<a href='function.rename'>function.rename</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\models\galleries_m.php 106
ERROR - 2009-08-15 03:08:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Session.php 662
ERROR - 2009-08-15 03:08:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\helpers\url_helper.php 541
ERROR - 2009-08-15 03:14:38 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:40 --> Severity: Notice  --> Undefined property: stdClass::$id D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\admin\form.php 18
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 03:14:55 --> 404 Page Not Found --> 
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:14:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 03:17:21 --> 404 Page Not Found --> 
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 03:17:45 --> 404 Page Not Found --> 
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 03:24:48 --> 404 Page Not Found --> 
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 03:24:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:16:40 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:16:46 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:16:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:17:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:17:46 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:17:51 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:17:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:50 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:52 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:53 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:23:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:24:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:25:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:04 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:20 --> Query error: Duplicate entry '英语培训' for key 'title'
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:26:46 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:53 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:26:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:27:19 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:27 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:28 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:31 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:31 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:27:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:27:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:27:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:27:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:28:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:28:01 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:28:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:28:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:28:25 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:28:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:43 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:28:46 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:28:53 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:28:54 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:28:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:45 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:49 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:50 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:51 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:52 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:52 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:53 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:55 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:56 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:56 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:30:58 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:30:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:31:16 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:31:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:35:26 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:35:28 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:35:46 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:35:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:36:15 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:36:32 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:36:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:37:41 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:37:49 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:37:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:42:41 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:42:45 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:42:45 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:42:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:43:12 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:43:14 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:43:25 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:43:32 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:43:32 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:08 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:10 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:10 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:12 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:27 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:57 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:57 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:44:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:44:59 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:45:04 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:45:05 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:26 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:45:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Session.php 662
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Session.php 662
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:46:50 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:46:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:47:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Session.php 662
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\controllers\contact.php:46) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:48:41 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:42 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:48:43 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:48:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:06 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:07 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:27 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:33 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:34 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:49:35 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:49:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:46 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:51:47 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:51:47 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 05:53:51 --> 404 Page Not Found --> 
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 05:53:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:50:56 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:57 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Session.php 662
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\plugins\captcha_pi.php:315) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:51:25 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:51:35 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:51:54 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:51:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:02 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:09 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:10 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:11 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:11 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:19 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:20 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:21 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:21 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:52 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:54 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:52:54 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:52:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:53:01 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:53:02 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:53:03 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:53:04 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 07:53:05 --> 404 Page Not Found --> 
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 07:53:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:24:04 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:04 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 20
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:24:12 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:24:36 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:24:51 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:24:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:25:02 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:25:21 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:25:33 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:25:49 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:25:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:26:02 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:26:11 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-15 10:26:25 --> 404 Page Not Found --> 
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 40
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Undefined variable: news D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
ERROR - 2009-08-15 10:26:25 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\themes\freshmedia\views\layouts\default.php 41
