<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-09 01:20:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:15 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:20:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:18 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:20:20 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-09 01:20:22 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-09 01:20:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:25 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:20:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:28 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:20:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:28 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:20:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:20:30 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:25:08 --> Severity: Notice  --> Undefined index:  category D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php 47
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Notice  --> Undefined index:  category D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php 47
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:25:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:164) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:27:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\controllers\products.php:34) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:35:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:47) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\application\modules\products\models\products_m.php:49) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 299
ERROR - 2009-08-09 01:39:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:39:49 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:39:50 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-09 01:39:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:39:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:39:53 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:00 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:03 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:03 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:05 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:06 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:08 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:08 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:40:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:40:14 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:42:38 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-09 01:42:41 --> 404 Page Not Found --> suppliers/5
ERROR - 2009-08-09 01:43:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\categories\views\admin\form.php 4
ERROR - 2009-08-09 01:43:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\categories\views\admin\form.php 9
ERROR - 2009-08-09 01:43:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:43:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 01:43:21 --> 404 Page Not Found --> 
ERROR - 2009-08-09 01:44:34 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:21:08 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:26:00 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:32:30 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:34:40 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:39:53 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 02:50:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 02:50:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 02:50:47 --> 404 Page Not Found --> 
ERROR - 2009-08-09 02:56:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 02:56:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 02:56:28 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:01:03 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-09 03:01:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:10 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:01:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-09 03:01:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:22 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:01:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:25 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-08-09 03:01:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-08-09 03:01:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:01:45 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:01:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:49 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:01:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:01:53 --> 404 Page Not Found --> 
ERROR - 2009-08-09 03:02:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:02:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:02:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:02:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-09 03:02:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:02:57 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:03:17 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-09 03:05:12 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:07:35 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:13:20 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:16:00 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:16:01 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:16:26 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-09 03:41:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:41:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:41:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:41:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:43:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:43:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:44:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:44:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:47:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:47:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:47:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:47:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:48:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:50:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:51:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:51:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:51:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:51:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:52:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:54:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:54:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:55:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:55:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:55:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:55:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:55:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:56:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:56:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:57:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-09 03:58:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
