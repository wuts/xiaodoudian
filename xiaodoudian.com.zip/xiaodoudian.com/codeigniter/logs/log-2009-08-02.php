<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-02 20:51:59 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:51:59 --> Severity: Notice  --> Undefined property: stdClass::$items /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:51:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:51:59 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:52:07 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:08 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:08 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:52:08 --> Severity: Notice  --> Undefined property: stdClass::$items /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:52:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:52:08 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:08 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:52:22 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:23 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:23 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:52:23 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:52:23 --> 404 Page Not Found --> 
ERROR - 2009-08-02 20:52:23 --> Severity: Notice  --> Undefined property: stdClass::$items /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:52:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/xiaodoudian.com/application/modules/news/views/rss.php 15
ERROR - 2009-08-02 20:53:58 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:54:04 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:54:18 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 20:54:19 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:26 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:26 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:28 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:30 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:30 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:32 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:32 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:34 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:34 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:36 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:36 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:37 --> Severity: Notice  --> Undefined index:  order /var/www/xiaodoudian.com/application/modules/comments/models/comments_m.php 71
ERROR - 2009-08-02 21:00:37 --> Severity: Notice  --> Undefined index:  order /var/www/xiaodoudian.com/application/modules/comments/models/comments_m.php 71
ERROR - 2009-08-02 21:00:37 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:37 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:40 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:40 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:40 --> Severity: Notice  --> Undefined index:  order /var/www/xiaodoudian.com/application/modules/comments/models/comments_m.php 71
ERROR - 2009-08-02 21:00:40 --> Severity: Notice  --> Undefined index:  order /var/www/xiaodoudian.com/application/modules/comments/models/comments_m.php 71
ERROR - 2009-08-02 21:00:40 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:40 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:49 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:49 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:00:53 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:00:53 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:04:55 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:04:55 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:08:14 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:08:17 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:08:17 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:08:19 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:08:19 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:08:35 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:08:35 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:08:39 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:08:39 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:09:43 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:09:43 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:09:44 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:09:44 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:09:45 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:09:45 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:09:48 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:09:48 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:15:24 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:15:24 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 21:16:51 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 21:16:51 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:16:51 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:16:55 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:16:55 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:16:55 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:16:57 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:17:00 --> Severity: Notice  --> Undefined index:  __cache_expires /var/www/xiaodoudian.com/application/libraries/Cache.php 217
ERROR - 2009-08-02 21:17:00 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:17:05 --> 404 Page Not Found --> 
ERROR - 2009-08-02 21:17:05 --> 404 Page Not Found --> 
ERROR - 2009-08-02 13:53:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-02 13:53:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-02 13:54:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 217
ERROR - 2009-08-02 13:55:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 13:56:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:05:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:05:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:05:10 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:09:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:09:48 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:09:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:09:52 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:09:58 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-02 14:10:45 --> 404 Page Not Found --> roles/images
ERROR - 2009-08-02 14:10:57 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:00 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:01 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:04 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:04 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:06 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:12 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:11:12 --> Language file contains no data: language/chinese/categories_lang.php
ERROR - 2009-08-02 14:12:21 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:12:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-02 14:12:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-02 14:12:22 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:12:24 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:12:25 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:12:27 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:12:28 --> 404 Page Not Found --> admin/images
ERROR - 2009-08-02 14:41:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:41:58 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:41:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-02 14:41:58 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian\application\modules\pages\views\admin\index.php 26
ERROR - 2009-08-02 14:42:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:42:01 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:46:27 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:46:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-02 14:46:28 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian\application\modules\comments\models\comments_m.php 71
ERROR - 2009-08-02 14:46:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:46:29 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:46:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:46:29 --> 404 Page Not Found --> 
ERROR - 2009-08-02 14:46:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian\application\libraries\Cache.php 217
ERROR - 2009-08-02 14:46:31 --> 404 Page Not Found --> 
