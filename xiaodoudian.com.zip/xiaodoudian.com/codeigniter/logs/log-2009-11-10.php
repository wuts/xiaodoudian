<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-11-10 11:32:09 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:32:09 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:32:09 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:32:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:32:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:32:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:34:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:34:20 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:02 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:02 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:02 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:02 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:02 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:35:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:35:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:43:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:43:41 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 11:43:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:44 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:51 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:43:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:43:51 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:05 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:05 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:06 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:31 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:47:32 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:47:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:47:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:48:56 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:48:56 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:48:56 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:03 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:03 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:03 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:03 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:49:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:04 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:04 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:04 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:49:04 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:49:04 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:12 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:52:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:22 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:53 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:52:53 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:52:55 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:53:29 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:53:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:53:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:08 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:08 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:54:09 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:54:09 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:55:40 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:55:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:55:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:38 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:39 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:57:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:57:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:57:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:19 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:23 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:25 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:26 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:28 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:50 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:58:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:50 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:58:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:58:51 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:14 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:15 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 11:59:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 11:59:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 11:59:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:00 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:29 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:03:29 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:03:31 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:32 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:33 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:34 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:34 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:35 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:36 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:37 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:03:38 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:40 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:41 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:41 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:41 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:04:41 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:04:47 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:49 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:50 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:57 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:58 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:58 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:04:58 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:05:00 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:05:00 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:00 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:05:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:05:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:05:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:13:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 12:13:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 12:13:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 12:14:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:07 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:08 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:09 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:13 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:13 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:13 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:13 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:31 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:31 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:31 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:31 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:14:32 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:14:34 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:35 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:36 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:14:37 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:16 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:15:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:15:18 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:15:19 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:36 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:23:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:23:37 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:23:40 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:23:40 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:23:46 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:21 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:21 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:21 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:21 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:21 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:21 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:23 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:23 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:24 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:39 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:24:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:24:40 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:24:42 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:25:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:16 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:25:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:25:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:25:18 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:25:18 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:22 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:24 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:25 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:28 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:31 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:35 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:35 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:35 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:36 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:36 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:37 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:39 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:39 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:45 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:45 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:45 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:46 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:46 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:27:46 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:27:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:27:46 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:10 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:10 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:11 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:28:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:11 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:27 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:28 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:28 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:28:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:54 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:54 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:54 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:28:54 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:54 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:55 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:55 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:28:55 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:28:55 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:58 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:58 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:58 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:58 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 12:29:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:59 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:59 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:59 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:29:59 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 12:29:59 --> 404 Page Not Found --> 
ERROR - 2009-11-10 12:30:00 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 13:32:57 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:33:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:33:01 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:33:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:33:08 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:33:08 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:33:08 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:33:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:33:12 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 13:46:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 13:46:21 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 13:46:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:25 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:32 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-10 13:46:34 --> Severity: Notice  --> Undefined property: stdClass::$id D:\xampp\htdocs\xiaodoudian.com\application\modules\galleries\views\admin\form.php 18
ERROR - 2009-11-10 13:46:37 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-10 13:46:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:42 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:43 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:43 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:43 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:43 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:46:43 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:46:43 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:22 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:23 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 13:48:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:48:23 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:48:25 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 13:48:27 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 13:49:06 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory D:\xampp\htdocs\xiaodoudian.com\application\libraries\Tinycimm.php 302
ERROR - 2009-11-10 13:49:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:06 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:49:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:06 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:49:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:06 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:49:06 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:06 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:49:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 13:49:07 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 13:49:07 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:15:08 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:15:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:19:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 14:19:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 14:19:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-10 14:41:12 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-10 14:41:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:15 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:16 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:17 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
ERROR - 2009-11-10 14:41:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-10 14:41:18 --> 404 Page Not Found --> 
