<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:47:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:47:20 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-09 12:47:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:47:24 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:52:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:53:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:56:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:56:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 12:58:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 12:58:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:53 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:53 --> 404 Page Not Found --> 
ERROR - 2009-11-09 12:58:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 12:58:53 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:00:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:00:52 --> Severity: Notice  --> Undefined property: CI_Loader::$validation D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-09 13:00:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\contact\views\index.php 23
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 13:00:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 13:03:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:03:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:03:59 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:04:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:04:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:04:20 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:04:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:04:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:04:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:04:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:04:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:04:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:04:42 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:04:42 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:04:44 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:04:44 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:10:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:10:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:10:44 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 1
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 3
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 4
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 5
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 5
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 6
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 21
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 25
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 37
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 42
ERROR - 2009-11-09 13:10:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 47
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 1
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 3
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 4
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 5
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 5
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 6
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 21
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 25
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 37
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 42
ERROR - 2009-11-09 13:12:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\staff\views\admin\edit.php 47
ERROR - 2009-11-09 13:14:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:14:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:14:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 13:14:16 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:14:16 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:14:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:14:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 13:14:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 13:14:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 14:03:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:03:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:03:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:04:01 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 14:04:01 --> 404 Page Not Found --> 
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 7
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 24
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 30
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 34
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 46
ERROR - 2009-11-09 14:04:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\admin\form.php 52
ERROR - 2009-11-09 14:26:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:26:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:26:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:26:14 --> Severity: Notice  --> unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 77 of 6911 bytes D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 8686
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:19 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:19 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:23 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:23 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:24 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:25 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:26 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:27:26 --> Severity: User Warning  --> application/cache/simplepie//47fcc4d58332e5949c895a71f2c0b7ca.spc is not writeable D:\xampp\htdocs\xiaodoudian.com\application\libraries\Simplepie.php 1779
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:27:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 14:28:10 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:28:10 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:28:10 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 14:28:13 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 14:28:13 --> 404 Page Not Found --> 
ERROR - 2009-11-09 14:28:14 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 14:28:14 --> 404 Page Not Found --> 
ERROR - 2009-11-09 14:28:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 14:28:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 14:28:15 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 14:28:15 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:04:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:04:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:04:33 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:04:35 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:04:35 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:16:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:16:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:16:14 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 15:16:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:16:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:40 --> Severity: Notice  --> unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 3322 of 10886 bytes D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 190
ERROR - 2009-11-09 15:35:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Exceptions.php:166) D:\xampp\htdocs\xiaodoudian.com\codeigniter\libraries\Output.php 230
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:44 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:49 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:49 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:50 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:50 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:53 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:35:53 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:35:53 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:02 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:11 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:36:48 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:26 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:37:50 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:21 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:21 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:31 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:31 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:33 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:38:33 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:43 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:52 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:38:56 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:44:27 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:44:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:44:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 15:44:39 --> 404 Page Not Found --> 
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 15:45:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:09:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:09:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:09:50 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:09:54 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-09 16:09:56 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-09 16:14:37 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 8
ERROR - 2009-11-09 16:15:13 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\modules\news\views\index.php 9
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:17 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:17 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:22 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:22 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:15:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:15:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:24:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:24:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:24:58 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:25:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:25:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:25:07 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:25:09 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:25:09 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:26:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:18 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:22 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:26:23 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:26:23 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:26:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:26:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:27:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:27:47 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:27:47 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:27:47 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:27:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:27:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:27:51 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:27:51 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:27:55 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-09 16:28:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:13 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:16 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:39 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\xiaodoudian.com\application\libraries\Admin_Controller.php 63
ERROR - 2009-11-09 16:28:43 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:43 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:43 --> Severity: Notice  --> Undefined index:  order D:\xampp\htdocs\xiaodoudian.com\application\modules\comments\models\comments_m.php 80
ERROR - 2009-11-09 16:28:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:46 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:48 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:48 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:48 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:28:52 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:28:52 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:11 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:11 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:12 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:12 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:18 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:18 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:19 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:19 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:29:20 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:29:20 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:30:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:30:45 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:30:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:30:46 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:32 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:31:32 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:34 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:31:34 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:36 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:31:36 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:31:39 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:31:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:31:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:34:39 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:34:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:34:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:34:45 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:34:45 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:34:46 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 16:34:46 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:35:31 --> 404 Page Not Found --> admin/images
ERROR - 2009-11-09 16:36:12 --> 404 Page Not Found --> 
ERROR - 2009-11-09 16:36:45 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:24 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:24 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:25 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:25 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:26 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:26 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:27 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:27 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:28 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:28 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:29 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:29 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:30 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:30 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:38 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:38 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:39 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:39 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:39 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:40 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:40 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:41 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:41 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:41 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:41 --> 404 Page Not Found --> 
ERROR - 2009-11-09 17:21:41 --> Severity: Notice  --> Undefined index:  __cache_expires D:\xampp\htdocs\xiaodoudian.com\application\libraries\Cache.php 225
ERROR - 2009-11-09 17:21:41 --> 404 Page Not Found --> 
