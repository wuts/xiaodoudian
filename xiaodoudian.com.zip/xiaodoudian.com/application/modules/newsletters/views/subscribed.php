<h2><?=lang('letter_subscriped_title');?></h2>
<p><?=lang('letter_subscribed_success');?></p>