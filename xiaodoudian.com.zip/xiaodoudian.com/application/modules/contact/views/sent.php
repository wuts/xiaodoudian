<h2><?=lang('contact_sent_title');?></h2>
<p><?=lang('contact_sent_text');?></p>