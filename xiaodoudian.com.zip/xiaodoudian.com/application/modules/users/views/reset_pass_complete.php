<h2><?= lang('user_password_reset_title')?></h2>
<p><?=$this->lang->line('user_password_reset_message'); ?></p>