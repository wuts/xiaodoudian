<?php

$lang['twitter_more'] 							= 'Suite &raquo;';
$lang['twitter_no_tweets'] 					= 'Aucun message pour le moment.';

?>