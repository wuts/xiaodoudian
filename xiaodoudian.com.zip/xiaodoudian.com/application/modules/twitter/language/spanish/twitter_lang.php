<?php

$lang['twitter_more'] 				= 'M&aacute;s &raquo;';
$lang['twitter_no_tweets'] 		= 'Nada se ha escrito hasta el momento.';

?>