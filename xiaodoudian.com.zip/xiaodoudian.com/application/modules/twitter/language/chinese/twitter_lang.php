<?php

$lang['twitter_more'] 							= 'More &raquo;';
$lang['twitter_no_tweets'] 					= 'None posted just yet.';

?>