<h2><?= lang('error_404_title'); ?></h2>

<p><?= sprintf(lang('error_404_message'), site_url('')); ?></p>