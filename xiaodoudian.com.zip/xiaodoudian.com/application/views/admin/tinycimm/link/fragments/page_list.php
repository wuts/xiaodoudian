<ul class="hidden">
	<?php echo $list_items; ?>
</ul>
