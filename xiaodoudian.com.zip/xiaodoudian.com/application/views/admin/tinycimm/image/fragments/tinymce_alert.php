<script type="text/javascript">
parent.TinyCIMMImage.removeOverlay();
parent.tinyMCEPopup.editor.windowManager.alert('<?=$message;?>');
</script>
