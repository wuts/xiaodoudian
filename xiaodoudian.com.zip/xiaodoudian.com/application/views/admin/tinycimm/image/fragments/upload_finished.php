<script type="text/javascript">
parent.TinyCIMMImage.removeOverlay();
parent.TinyCIMMImage.assetUploaded(<?=$folder_id;?>);
</script>";
