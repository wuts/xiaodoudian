	
	<? if(!empty($pagination['links'])): ?>
	
	<div class="paginate">
		<?=$pagination['links'];?>
	</div>
	
	<!-- Pages: </p> -->
	<? endif; ?>