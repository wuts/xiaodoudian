<p class="float-left"><a href="http://pyrocms.com/" target="_blank">PyroCMS</a> v<?=CMS_VERSION;?></p>
<p class="float-right">Copyright &copy; 2008 - <?=date('Y');?> <a href="http://philsturgeon.co.uk/" target="_blank">Phil Sturgeon</a>.</p>
