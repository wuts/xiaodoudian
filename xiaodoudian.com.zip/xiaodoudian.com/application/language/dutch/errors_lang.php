<?php

// Error 404
$lang['error_404_title'] = 'Pagina niet gevonden';
$lang['error_404_message'] = 'De gekozen pagina kon niet worden gevonden, klik <a href="%s">hier</a> om terug te gaan naar de hoofdpagina.';

// Database
$lang['error_invalid_db_group'] = 'De database gebruikt een ongeldige configuratie groep "%s".';

?>