<?php

// General Email Language
$lang['email_greeting'] = 'Hallo %s,';

$lang['email_signature'] = 'Bedankt,';

?>