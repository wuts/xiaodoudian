<?php

/* 
==== NOTE ====

I haven't changed the general_bookmarks.php view, because I didn't found any controller which load it.
So I've just created the two needed lang-vars here for later using like:
sprintf($this->lang->line('sbm_post_to'), 'social-network e.g "Facebook" or "Delicious" etc.'); 

*/

// general bookmarks
$lang['sbm_post_to'] = 'Plaats dit artikel op %s';

// toolbar
$lang['tb_title'] = 'Deel dit met anderen';
?>