<?php

// modules title
$lang['mod_title'] = 'Modules';

?>