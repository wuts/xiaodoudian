<?php

// Error 404
$lang['error_404_title'] = '页面不存在';
$lang['error_404_message'] = '查找的页面不存在,请点击 <a href="%s">这里</a>前往主页';

// Database
$lang['error_invalid_db_group'] = '数据局试图使用一个非法的数据组 "%s".';

?>