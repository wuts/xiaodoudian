<?php

// modules title
$lang['mod_title'] = '模块';

?>