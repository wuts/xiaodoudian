<?php

// General Email Language
$lang['email_greeting'] = 'Hello %s,';

$lang['email_signature'] = 'Thank you,';

?>