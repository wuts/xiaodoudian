<?php

// General Email Language
$lang['email_greeting'] = 'Bonjour %s,';

$lang['email_signature'] = 'Merci,';

?>