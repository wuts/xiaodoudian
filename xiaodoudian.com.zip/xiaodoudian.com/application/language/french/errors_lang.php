<?php

// Error 404
$lang['error_404_title'] = 'Page Non Trouvée';
$lang['error_404_message'] = 'La pas que vous recherchez n\'a pu être trouvée, veuillez cliquer <a href="%s">ici</a> pour revenir à la page d\'accueil.';

// Database
$lang['error_invalid_db_group'] = 'La Base de données tente d\'utiliser un groupe de configuration invalide "%s".';

?>