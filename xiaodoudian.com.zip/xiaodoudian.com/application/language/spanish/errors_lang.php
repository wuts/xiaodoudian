<?php

// Error 404
$lang['error_404_title'] 			= 'Extraviada';
$lang['error_404_message'] 			= 'No pudimos encontrar la p&aacute;gina que estabas buscando, por favor ve a la <a href="%s">p&aacute;gina principal</a>.';

// Database
$lang['error_invalid_db_group'] 	= 'La base de datos esta tratando de utilizar un grupo de configuraci&oacute;n inv&aacute;lido "%s".';

?>