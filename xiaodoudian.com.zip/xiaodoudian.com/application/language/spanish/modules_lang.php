<?php

// modules title
$lang['mod_title'] = 'M&oacute;dulos';

?>