<?php

// General Email Language
$lang['email_greeting'] 	= 'Hola %s,';

$lang['email_signature'] 	= 'Gracias,';

?>