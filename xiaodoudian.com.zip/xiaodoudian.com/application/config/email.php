<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['mailtype'] = 'html';

/*
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.example.com';
$config['smtp_user'] = 'username';
$config['smtp_pass'] = 'password';
$config['smtp_port'] = '465';
*/

?>